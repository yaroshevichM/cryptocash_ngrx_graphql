import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Params } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { map, tap, toArray } from 'rxjs/operators';
import { NotificationComponent } from 'src/app/modules/shared/components/notification/notification.component';
import { IAppState } from 'src/app/store/appState';
import { ICard } from '../../models/Card';
import { IService } from '../../models/Service';
import { AllCardsRequestedAction } from '../../store/actions/card.actions';
import { serviceByIdRequestedAction } from '../../store/actions/services.action';
import { CreateTransactionRequestedAction } from '../../store/actions/transaction.actions';
import { selectAllCardsInner } from '../../store/selectors/card.selector';
import { selectCurrentService } from '../../store/selectors/services.selector';
import { IServicesState } from '../../store/state/services.state';


@Component({
  selector: 'app-terminal',
  templateUrl: './terminal.component.html',
  styleUrls: ['./terminal.component.scss']
})
export class TerminalComponent implements OnInit {

  private userCards$ = this._store.select(selectAllCardsInner).subscribe(userCards => {
    this.userCards = userCards
    if (userCards.length) {
      this.currency = userCards[0].currencyType
    }
  })
  public paymentForm: FormGroup;
  public currentService$;
  private transactionType: string;
  public userCards: ICard[];
  currency: any;

  constructor(private _store: Store<IAppState>, private _activeRoute: ActivatedRoute, private _snackBar: MatSnackBar) {
    this._activeRoute.params.subscribe((params: Params) => {
      this._store.dispatch(new serviceByIdRequestedAction(params.id))
    })
  }

  ngOnInit(): void {
    this._store.dispatch(new AllCardsRequestedAction({ userId: window.sessionStorage.getItem('currentUserId') }))
    this.initPaymentForm();
    this.currentService$ = this._store.select(selectCurrentService).subscribe((currentServiceData) => {
      if (currentServiceData) {
        this.paymentForm.patchValue({
          receiverCardNumber: currentServiceData.cardNumber
        })
        this.transactionType = currentServiceData.name
      }
    })
  }

  private initPaymentForm() {
    this.paymentForm = new FormGroup({
      receiverCardNumber: new FormControl('', Validators.required),
      transactionAmount: new FormControl('', Validators.required),
      senderCardId: new FormControl('', Validators.required),
      description: new FormControl('')
    });
  }

  public createTransaction() {

    if(!this.handleForm(this.paymentForm)) {
      return false
    }

    const transactionRequestValue = this.paymentForm.value;
    transactionRequestValue.type = this.transactionType;
    transactionRequestValue.currency = this.currency;
    transactionRequestValue.transactionAmount = +transactionRequestValue.transactionAmount;
    console.log(transactionRequestValue);
    this._store.dispatch(new CreateTransactionRequestedAction(transactionRequestValue))
  }

  private handleForm(form) {
    if (!form.valid) {
      this._snackBar.openFromComponent(NotificationComponent, {
        duration: 2500,
        horizontalPosition: 'right',
        data: { text: 'Input data are invalid', type: 'error' },
      });
      return false
    }
    return true
  }

}
