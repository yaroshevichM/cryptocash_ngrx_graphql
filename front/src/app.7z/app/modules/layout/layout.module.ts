import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from './components/layout/layout.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AccountsListComponent } from './components/accounts-list/accounts-list.component';
import { AccountDetailsComponent } from './components/account-details/account-details.component';
import { EffectsModule } from '@ngrx/effects';
import { ServicesEffects } from '../layout/store/effects/services.effects';
import { BalanceEffects } from '../layout/store/effects/balance.effects';
import { TransactionEffects } from '../layout/store/effects/transaction.effects';
import { ExchangeRatesEffects } from '../layout/store/effects/exchange-rates.effects';
import { CardEffects } from '../layout/store/effects/card.effects';
import { CreateCardComponent } from './components/create-card/create-card.component';
import { ProfileComponent } from "../layout/components/profile/profile.component";
import { ServicesComponent } from './components/services/services.component';
import { TerminalComponent } from './components/terminal/terminal.component';
import { ReactiveComponentModule } from '@ngrx/component';

const layoutRoutes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      { path: 'dashboard', component: DashboardComponent },
      { path: 'accounts', component: AccountsListComponent },
      { path: 'accounts/:cardId', component: AccountDetailsComponent },
      { path: 'create-account', component: CreateCardComponent },
      { path: 'profile', component: ProfileComponent },
      { path: 'services', component: ServicesComponent },
      { path: 'terminal/:id', component: TerminalComponent },
    ],
  },
];

@NgModule({
  exports: [RouterModule],
  declarations: [
    LayoutComponent,
    DashboardComponent,
    AccountsListComponent,
    AccountDetailsComponent,
    CreateCardComponent,
    ProfileComponent,
    ServicesComponent,
    TerminalComponent
  ],
  imports: [
    RouterModule.forChild(layoutRoutes),
    CommonModule,
    SharedModule,
    ReactiveComponentModule,
    EffectsModule.forFeature([
      ServicesEffects,
      BalanceEffects,
      ExchangeRatesEffects,
      TransactionEffects,
      CardEffects,
    ]),
  ],
})
export class LayoutModule {}
