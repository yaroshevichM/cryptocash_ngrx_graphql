export interface IService {
   id: string
   name: string,
   cardNumber: string
}