import { initialUserBalanceState } from '../state/balance.state';
import { EBalanceActions, BalanceActions } from '../actions/balance.actions';

export const balanceReducer = (
  state = initialUserBalanceState,
  action: BalanceActions
) => {
  switch (action.type) {
    case EBalanceActions.BALANCE_REQUESTED:
      return { ...state, loading: true };
    case EBalanceActions.BALANCE_COMPLETED:
      return { ...state, userBalance: action.payload, loading: false };
    default:
      return { ...state };
  }
};
