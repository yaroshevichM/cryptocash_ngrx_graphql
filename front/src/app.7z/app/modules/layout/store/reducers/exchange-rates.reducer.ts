import { initialExchangeRatesState } from "../state/exchange-rates.state";
import { EExchangeRates, ExchangeRatesAction } from "../actions/exchange-rates.action";

export const exchangeRatesReducer = (state = initialExchangeRatesState, action: ExchangeRatesAction) => {
   switch (action.type) {
      case EExchangeRates.EXCHANGE_RATES_COMPLETED:
         return { ...state, exchangeRates: action.payload, loading: false }

      case EExchangeRates.EXCHANGE_RATES_COMPLETED:
         return { ...state, loading: true }

      default:
         return { ...state }
   }
}