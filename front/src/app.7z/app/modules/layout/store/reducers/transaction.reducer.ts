import { initialTransactionState } from '../state/transaction.state';
import {
  ETransactionActions,
  TransactionAction,
} from '../actions/transaction.actions';

export const transactionReducer = (
  state = initialTransactionState,
  action: TransactionAction
) => {
  switch (action.type) {
    case ETransactionActions.ALL_TRANSACTIONS_COMPLETED:
      return { ...state, transactions: action.payload, loading: false };
    case ETransactionActions.CARD_TRANSACTIONS_COMPLETED:
      return { ...state, currentCardTransactions: action.payload, loading: false };
    case ETransactionActions.ALL_TRANSACTIONS_REQUESTED:
    case ETransactionActions.CARD_TRANSACTIONS_REQUESTED:
      return { ...state, loading: true };
    default:
      return { ...state };
  }
};
