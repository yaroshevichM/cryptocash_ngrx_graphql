import { IUserBalanceState } from "../state/balance.state";
import { IAppState } from "../../../../store/appState";
import {createSelector} from "@ngrx/store"

const selectUserBalance = (state: IAppState) => state.userBalance;

export const selectUserBalanceInner = createSelector(
   selectUserBalance,
   (state: IUserBalanceState) => state.userBalance
);

export const selectUserBalanceLoader = createSelector(
   selectUserBalance,
   (state: IUserBalanceState) => state.loading
);