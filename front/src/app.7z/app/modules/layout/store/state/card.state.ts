import { ICard } from "../../models/Card";

export interface ICardsState {
   cards: Array<ICard>,
   currentCard: ICard
   loading: boolean
}

export const initialCardsState = {
   cards: [],
   currentCard: null,
   loading: false
}