export interface IExchangeRates {
   type: string,
   name: string,
   USD: number
}

export interface IExchangeRatesState {
   exchangeRates: Array<IExchangeRates>
   loading: boolean
}

export const initialExchangeRatesState = {
   exchangeRates: null,
   loading: false
}