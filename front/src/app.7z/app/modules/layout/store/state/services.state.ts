import { IService } from "../../models/Service";

export interface IServicesState {
   servicesData: Array<IService>
   currentService: IService
   loading: boolean
}

export const initialServicesState = {
   servicesData: null,
   currentService: null,
   loading: false
}