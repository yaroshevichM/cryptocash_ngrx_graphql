import { ITransaction } from "../../models/Transaction";

export interface ITransactionState {
   transactions: Array<ITransaction>,
   currentCardTransactions: Array<ITransaction>,
   loading: boolean
}

export const initialTransactionState = {
   transactions: null,
   currentCardTransactions: null,
   loading: false
}