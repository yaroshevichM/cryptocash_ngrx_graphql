import { ActionReducerMap } from "@ngrx/store";
import { servicesReducer } from "../modules/layout/store/reducers/services.reducer";
import { balanceReducer } from "../modules/layout/store/reducers/balance.reducer";
import { transactionReducer } from "../modules/layout/store/reducers/transaction.reducer";
import { cardReducer } from "../modules/layout/store/reducers/card.reducer";
import { exchangeRatesReducer } from "../modules/layout/store/reducers/exchange-rates.reducer";
import { IServicesState } from "../modules/layout/store/state/services.state";
import { IUserBalanceState } from "../modules/layout/store/state/balance.state";
import { IExchangeRatesState } from "../modules/layout/store/state/exchange-rates.state";
import { ITransactionState } from "../modules/layout/store/state/transaction.state";
import { ICardsState } from "../modules/layout/store/state/card.state";
import { IUserState } from "./states/user.state";
import { userReducer } from "./reducers/user.reducer";

export interface IAppState {
   // router: RouterState,
   user: IUserState,
   services: IServicesState,
   userBalance: IUserBalanceState,
   exchangeRates: IExchangeRatesState,
   transactions: ITransactionState,
   cards: ICardsState,
}

export const initialAppState: IAppState = {
   // router: RouterReducerState,
   user: null,
   services: null,
   userBalance: null,
   exchangeRates: null,
   transactions: null,
   cards: null,
}

export const appReducers: ActionReducerMap<IAppState, any> = {
   user: userReducer,
   services: servicesReducer,
   userBalance: balanceReducer,
   exchangeRates: exchangeRatesReducer,
   transactions: transactionReducer,
   cards: cardReducer,
} 